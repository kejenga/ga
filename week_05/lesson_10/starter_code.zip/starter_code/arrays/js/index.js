$(function() {
    console.log( "document is ready!" );
   
});